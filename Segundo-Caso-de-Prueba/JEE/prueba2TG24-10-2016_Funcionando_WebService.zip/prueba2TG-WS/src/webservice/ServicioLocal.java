package webservice;

import java.rmi.Remote;


public interface ServicioLocal extends Remote {
	
	public byte[] enviarProduccionJeeWebService();	
	
	public void enviarProduccionOtraAPPwebService(byte[] bytes);
}



