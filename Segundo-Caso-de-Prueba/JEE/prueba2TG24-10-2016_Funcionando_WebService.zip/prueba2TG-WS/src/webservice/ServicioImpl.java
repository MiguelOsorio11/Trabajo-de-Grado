package webservice;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import javax.jws.WebService;

import org.domain.prueba2tg.ejb.impl.BancoViewModelEJB;


public class ServicioImpl implements ServicioLocal  {
	
	private final String RUTA_JEE_XML_AUX="D://prueba2TG_xmls//jee-WS.xml";
	private final String RUTA_JEE_ORG="D://prueba2TG_xmls//jee.xml";
	
	public ServicioImpl() {
		// TODO Auto-generated constructor stub
		
	}
	
	
	
	/**
	 * Se envia el viewmodel de la aplicaci�n de jee
	 * el archivo que se envia es el jee, el cual maneja la aplicaci�n.
	 */
	@Override
	public byte[] enviarProduccionJeeWebService() 
	{
		File archivo = new File(RUTA_JEE_ORG);
		
		byte[] archivoBytes = null;
		//tama�o del archivo
		long tamanoArch = archivo.length(); 
		//se crea el array con el tama�o del archivo.
		archivoBytes = new byte[(int) tamanoArch]; 
		try
		{
		//variable que permite leer el archivo
		FileInputStream docu = new FileInputStream(archivo);
		// se leen los bytes del archivo y se van insertando en el array de bytes creado.
		int numBytes = docu.read(archivoBytes);

		//es muy importante cerrar despues de la lectura
		docu.close(); 
		}
		catch (FileNotFoundException e)
		{
		System.out.println("No se ha encontrado el archivo.");
		}
		catch (IOException e)
		{
		System.out.println("No se ha podido leer el archivo.");
		}			
		return archivoBytes;
	}
	
	/**
	 * Este metodo se encarga de traer el viewmodel de otra aplicaci�n por medio de de un arreglo de bytes
	 * este viewmodel se almacenara directamente en un archivo auxiliar, no en el archivo que manipula la aplicaci�n
	 * en produccion directamente
	 */
	@Override
	public void enviarProduccionOtraAPPwebService(byte[] bytes)
	{		
		try {
			OutputStream out = new FileOutputStream(RUTA_JEE_XML_AUX);
			
			out.write(bytes);			
			out.close();			

		} catch (Exception e) {
			System.out.println(e.getCause());
			System.out.println(e.getMessage());
		}
	}	
	

}
