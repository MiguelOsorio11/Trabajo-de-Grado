@javax.xml.bind.annotation.XmlSchema(namespace = "http://webservice", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package webservice;
