package org.domain.prueba2tg.ejb.local;

import javax.ejb.Local;
import org.domain.prueba2tg.action.BancoAction;
import org.domain.prueba2tg.action.UserInterfaceManager;


public @Local interface IBancoViewModelLocal {
	
	public UserInterfaceManager cargarXMLJAXB(String RUTA);
	
	public void guardarXMLJAXB(UserInterfaceManager userInterfaceManager);	
	
	public void agregarObserver(BancoAction bancoAction);
	
	public boolean validarViewModel_ViewPart(UserInterfaceManager interfaceManager,String idNombre);
	
	public void ejecutarHilos();

}
