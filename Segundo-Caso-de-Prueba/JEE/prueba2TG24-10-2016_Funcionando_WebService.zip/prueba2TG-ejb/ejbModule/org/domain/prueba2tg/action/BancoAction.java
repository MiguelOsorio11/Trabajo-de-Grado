package org.domain.prueba2tg.action;

import java.util.ArrayList;
import java.util.List;
import java.util.Observable;
import java.util.Observer;

import javax.faces.bean.ManagedBean;

import org.domain.prueba2tg.action.UserInterfaceManager.ContenedorVistaIngresoViewModel;
import org.domain.prueba2tg.action.UserInterfaceManager.ContenedorVistaIngresoViewModel.ContenedorIngresoViewModel;
import org.domain.prueba2tg.action.UserInterfaceManager.ContenedorVistaIngresoViewModel.ContenedorIngresoViewModel.IngresoVM;
import org.domain.prueba2tg.action.UserInterfaceManager.ContenedorVistaRetiroViewModel;
import org.domain.prueba2tg.action.UserInterfaceManager.ContenedorVistaRetiroViewModel.ContenedorRetiroViewModel;
import org.domain.prueba2tg.action.UserInterfaceManager.ContenedorVistaRetiroViewModel.ContenedorRetiroViewModel.RetiroVM;
import org.domain.prueba2tg.action.UserInterfaceManager.ViewModel;
import org.domain.prueba2tg.action.UserInterfaceManager.ViewPart;
import org.domain.prueba2tg.ejb.local.IBancoViewModelLocal;
import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;

@ManagedBean
@Name("bancoAction")
@Scope(ScopeType.SESSION)
public class BancoAction implements Observer{
	
	private final String RUTA_JEE_XML_ORG="D://prueba2TG_xmls//jee.xml";
	
	// @In es para que inyecte el EJB y lo conecte con el action
	@In(value = "bancoViewModelEJB", create = true)
	private IBancoViewModelLocal bancoViewModelLocal;
	
	private UserInterfaceManager interfaceManager=null;
	
	/**CONTENEDORES DEL VIEW MODEL DEL INGRESO*/
	
	private ContenedorVistaIngresoViewModel contenedorVistaIngresoViewModel;
	
	private ContenedorIngresoViewModel contenedorIngresoViewModel;
	
	private IngresoVM ingresoVM;
	
	private List<IngresoVM> listaIngresoVMs;
	
	/**CONTENEDOR DEL VIEW MODEL DEL RETIRO*/
	
	private ContenedorVistaRetiroViewModel contenedorVistaRetiroViewModel;
	
	private ContenedorRetiroViewModel contenedorRetiroViewModel;
	
	private RetiroVM retiroVM;
	
	private List<RetiroVM> listaRetiroVMs;
	
	private ViewPart viewPartIngreso;
	
	private ViewPart viewPartRetiro;
	
	private ViewModel viewModelIngreso;
	
	private ViewModel viewModelRetiro;
	
	private String identificadorViewModelIngreso;
	private String identificadorViewModelRetiro;


	public BancoAction() {		
		
	}
	
	public void empezarBancoAction(){
		// TODO Auto-generated constructor stub
		
		interfaceManager = bancoViewModelLocal.cargarXMLJAXB(RUTA_JEE_XML_ORG);

		//se ejecutan los dos hilos
		bancoViewModelLocal.ejecutarHilos();
		
		ingresoVM= new IngresoVM();
		retiroVM= new RetiroVM();
		
		
		if(interfaceManager==null){
			interfaceManager =new UserInterfaceManager();
			
			contenedorVistaIngresoViewModel = new ContenedorVistaIngresoViewModel();
			contenedorIngresoViewModel = new ContenedorIngresoViewModel();			
			contenedorVistaIngresoViewModel.setContenedorIngresoViewModel(contenedorIngresoViewModel);// se enlazan los dos anteriores contenedores
			listaIngresoVMs = new ArrayList<UserInterfaceManager.ContenedorVistaIngresoViewModel.ContenedorIngresoViewModel.IngresoVM>();
					
			contenedorVistaRetiroViewModel = new ContenedorVistaRetiroViewModel();
			contenedorRetiroViewModel= new ContenedorRetiroViewModel();
			contenedorVistaRetiroViewModel.setContenedorRetiroViewModel(contenedorRetiroViewModel);// se enlazan los dos anteriores contenedores.
			listaRetiroVMs = new ArrayList<UserInterfaceManager.ContenedorVistaRetiroViewModel.ContenedorRetiroViewModel.RetiroVM>();
			
		}else{
			
			contenedorVistaIngresoViewModel = interfaceManager.getContenedorVistaIngresoViewModel();
			contenedorIngresoViewModel = contenedorVistaIngresoViewModel.getContenedorIngresoViewModel();
			listaIngresoVMs = (List<IngresoVM>) contenedorIngresoViewModel.getIngresoVM();
			
			contenedorVistaRetiroViewModel = interfaceManager.getContenedorVistaRetiroViewModel();
			contenedorRetiroViewModel= contenedorVistaRetiroViewModel.getContenedorRetiroViewModel();
			listaRetiroVMs = (List<RetiroVM>) contenedorRetiroViewModel.getRetiroVM();
			
		}
		
		identificadorViewModelIngreso = ContenedorVistaIngresoViewModel.class.getSimpleName()+"JEE";
		identificadorViewModelRetiro = ContenedorRetiroViewModel.class.getSimpleName() + "JEE";
		
		/**Se ingresa las viewpart al userinterface manager, primero se valida de que no se hayan agregado antes*/
		validarViewParts();

		agregarObserver();	
	}
	
	/**
	 * Se valida que las viewpart y los viewmodel no esten almacenados en la producci�n xml,
	 * si ya estan registrados, se sigue el proceso.
	 * @param nombre
	 */
	private void validarViewParts(){
		 if(!bancoViewModelLocal.validarViewModel_ViewPart(interfaceManager, identificadorViewModelIngreso)){
			 
			 viewPartIngreso= new ViewPart();
			 viewPartIngreso.setIdentificador(identificadorViewModelIngreso);
			 interfaceManager.getViewPart().add(viewPartIngreso);
			
			 
			 viewModelIngreso = new ViewModel();
			 viewModelIngreso.setViewPart(identificadorViewModelIngreso);
			 interfaceManager.getViewModel().add(viewModelIngreso);
			 
			 viewPartIngreso.setViewModel(viewModelIngreso.getIdViewModel());
			 
		 }
		 if(!bancoViewModelLocal.validarViewModel_ViewPart(interfaceManager, identificadorViewModelRetiro)){
			
			 /**Se registra la viewpart de emf*/
			viewPartRetiro = new ViewPart();
			viewPartRetiro.setIdentificador(identificadorViewModelRetiro);
			interfaceManager.getViewPart().add(viewPartRetiro);
			
			viewModelRetiro = new ViewModel();
			viewModelRetiro.setViewPart(identificadorViewModelRetiro);	
			interfaceManager.getViewModel().add(viewModelRetiro);
			
			viewPartRetiro.setViewModel(viewModelRetiro.getIdViewModel());
		 }
	}
	
	/**
	 * Metodo que guarda el ingreso que se hace del banco
	 */
	public void guardarIngreso(){
		
		interfaceManager.getContenedorVistaIngresoViewModel().getContenedorIngresoViewModel().getIngresoVM().add(ingresoVM);
		ingresoVM = new IngresoVM();
		bancoViewModelLocal.guardarXMLJAXB(interfaceManager);	
	}
	
	/**
	 * Metodo que guarda el retiro que se hace del banco
	 */
	public void guardarRetiro(){
		
		interfaceManager.getContenedorVistaRetiroViewModel().getContenedorRetiroViewModel().getRetiroVM().add(retiroVM);
		retiroVM = new RetiroVM();
		bancoViewModelLocal.guardarXMLJAXB(interfaceManager);
		
	}
	
	public void agregarObserver(){
		bancoViewModelLocal.agregarObserver(this); //se agrega la clase que va a observar al observador		
	}
	
	
	@Override
	public void update(Observable o, Object userInterfaceManager) {
		// TODO Auto-generated method stub
		
		// Acquire Request Context instance
//		RequestContext context = RequestContext.getCurrentInstance();
		
		interfaceManager =  (UserInterfaceManager)userInterfaceManager;		
		
		contenedorIngresoViewModel= interfaceManager.getContenedorVistaIngresoViewModel().getContenedorIngresoViewModel();
		listaIngresoVMs= contenedorIngresoViewModel.getIngresoVM();
		
		contenedorRetiroViewModel = interfaceManager.getContenedorVistaRetiroViewModel().getContenedorRetiroViewModel();
		listaRetiroVMs=contenedorRetiroViewModel.getRetiroVM();
		
//		 FacesContext.getCurrentInstance().getPartialViewContext().getRenderIds().add("panel:panelRetiro");
		
//		context.update("tablaRetiro");
		
	}
	
	
	/**GET AND SETTERS*/

	public ContenedorVistaIngresoViewModel getContenedorVistaIngresoViewModel() {
		return contenedorVistaIngresoViewModel;
	}

	public void setContenedorVistaIngresoViewModel(
			ContenedorVistaIngresoViewModel contenedorVistaIngresoViewModel) {
		this.contenedorVistaIngresoViewModel = contenedorVistaIngresoViewModel;
	}

	public ContenedorIngresoViewModel getContenedorIngresoViewModel() {
		return contenedorIngresoViewModel;
	}

	public void setContenedorIngresoViewModel(
			ContenedorIngresoViewModel contenedorIngresoViewModel) {
		this.contenedorIngresoViewModel = contenedorIngresoViewModel;
	}

	public IngresoVM getIngresoVM() {
		return ingresoVM;
	}

	public void setIngresoVM(IngresoVM ingresoVM) {
		this.ingresoVM = ingresoVM;
	}

	public List<IngresoVM> getListaIngresoVMs() {
		return listaIngresoVMs;
	}

	public void setListaIngresoVMs(List<IngresoVM> listaIngresoVMs) {
		this.listaIngresoVMs = listaIngresoVMs;
	}

	public ContenedorVistaRetiroViewModel getContenedorVistaRetiroViewModel() {
		return contenedorVistaRetiroViewModel;
	}

	public void setContenedorVistaRetiroViewModel(
			ContenedorVistaRetiroViewModel contenedorVistaRetiroViewModel) {
		this.contenedorVistaRetiroViewModel = contenedorVistaRetiroViewModel;
	}

	public ContenedorRetiroViewModel getContenedorRetiroViewModel() {
		return contenedorRetiroViewModel;
	}

	public void setContenedorRetiroViewModel(
			ContenedorRetiroViewModel contenedorRetiroViewModel) {
		this.contenedorRetiroViewModel = contenedorRetiroViewModel;
	}

	public RetiroVM getRetiroVM() {
		return retiroVM;
	}

	public void setRetiroVM(RetiroVM retiroVM) {
		this.retiroVM = retiroVM;
	}

	public List<RetiroVM> getListaRetiroVMs() {
		return listaRetiroVMs;
	}

	public void setListaRetiroVMs(List<RetiroVM> listaRetiroVMs) {
		this.listaRetiroVMs = listaRetiroVMs;
	}

	public ViewPart getViewPartIngreso() {
		return viewPartIngreso;
	}

	public void setViewPartIngreso(ViewPart viewPartIngreso) {
		this.viewPartIngreso = viewPartIngreso;
	}

	public ViewPart getViewPartRetiro() {
		return viewPartRetiro;
	}

	public void setViewPartRetiro(ViewPart viewPartRetiro) {
		this.viewPartRetiro = viewPartRetiro;
	}

	public ViewModel getViewModelIngreso() {
		return viewModelIngreso;
	}

	public void setViewModelIngreso(ViewModel viewModelIngreso) {
		this.viewModelIngreso = viewModelIngreso;
	}

	public ViewModel getViewModelRetiro() {
		return viewModelRetiro;
	}

	public void setViewModelRetiro(ViewModel viewModelRetiro) {
		this.viewModelRetiro = viewModelRetiro;
	}	
}
