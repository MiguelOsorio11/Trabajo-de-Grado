package org.domain.prueba2tg.ejb.impl;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.Observable;

import javax.ejb.Stateless;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.ws.Endpoint;

import org.domain.prueba2tg.action.BancoAction;
import org.domain.prueba2tg.action.UserInterfaceManager;
import org.domain.prueba2tg.action.UserInterfaceManager.ContenedorVistaIngresoViewModel.ContenedorIngresoViewModel.IngresoVM;
import org.domain.prueba2tg.action.UserInterfaceManager.ContenedorVistaRetiroViewModel.ContenedorRetiroViewModel.RetiroVM;
import org.domain.prueba2tg.ejb.local.IBancoViewModelLocal;
import org.jboss.seam.annotations.Name;
import org.xml.sax.SAXException;

import webservice.ServicioImpl;
import webservice.ServicioImplService;

@Stateless
@Name("bancoViewModelEJB")
public class BancoViewModelEJB extends Observable implements IBancoViewModelLocal{

	private final String RUTA_JEE_XML_AUX="D://prueba2TG_xmls//jee-WS.xml";
	private final String RUTA_JEE_XML_ORG="D://prueba2TG_xmls//jee.xml";	
	
	
	private ServicioImpl servicioLocal;
	private ServicioImplService servicioImpl;
	
	

	public BancoViewModelEJB() {
		
	}
	
	/**
	 * Metodo que se encarga de validar que el identificador del viewmodel y viewpart no esten
	 * registrados en la lista del userinterfacemanager
	 * @param idNombre
	 * @return true si se encuentra el id registrado, false de lo contrario.
	 */
	public boolean validarViewModel_ViewPart(UserInterfaceManager interfaceManager,String idNombre){
		
		if(!interfaceManager.getViewPart().isEmpty()){
		
			for (int i = 0; i < interfaceManager.getViewPart().size(); i++) {
				if(interfaceManager.getViewPart().get(i).getIdentificador().equals(idNombre))
					return true;
			}
		}
		return false;
	}
	
	/**
	 * Metodo que permite cargar la producci�n XML del Userinterfacemanager que contiene el viewmodel del banco.
	 * @return todos los viewmodel del proyecto banco, contenidos dentro del userinterfacemanager
	 */
	public UserInterfaceManager cargarXMLJAXB(String RUTA){

		UserInterfaceManager userInterfaceManager = null;
		 	try {

				File file = new File(RUTA);
		 		JAXBContext jaxbContext = JAXBContext.newInstance(UserInterfaceManager.class);

				Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
				userInterfaceManager = (UserInterfaceManager) jaxbUnmarshaller.unmarshal(file);
				
				
//				System.out.println(userInterfaceManager);

			  } catch (JAXBException e) {
				e.printStackTrace();
			  }
		 	
		 return userInterfaceManager;
		
	}
	
	/**
	 * 
	 * @param userInterfaceManager
	 */
	public void guardarXMLJAXB(UserInterfaceManager userInterfaceManager){

		 try {

			 File file = new File(RUTA_JEE_XML_ORG);    //ruta archivo original
			 File file_Aux= new File(RUTA_JEE_XML_AUX); //ruta archivo auxiliar
			JAXBContext jaxbContext = JAXBContext.newInstance(UserInterfaceManager.class);

			Marshaller jaxbMarshaller = jaxbContext.createMarshaller();

			// output pretty printed
			jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
			
			//Se guarda el objeto en el archivo original
			jaxbMarshaller.marshal(userInterfaceManager, file);
//			jaxbMarshaller.marshal(userInterfaceManager, System.out);
			
			//se guarda el objeto en el archivoa auxiliar para que haya integraci�n en los datos de los dos archivos
			jaxbMarshaller.marshal(userInterfaceManager, file_Aux);			
			
			/**Se notifica a los observadores que hay un cambio
			 * esto se hace para que se ejecute el webservice de jee a emf*/				
			
//			notifyObservers(userInterfaceManager);
//			setChanged();
			
		  } catch (JAXBException e) {
			e.printStackTrace();
			System.out.println("ERROR MARSHEANDO LOS DOS");
		  }
	}	
	

	@Override
	public void agregarObserver(BancoAction bancoAction) {
		
		this.addObserver(bancoAction);
	}
	
	/**
	 * Metodo que permite ejecutar los hilos que contiene la clase BancoViewModelEJB
	 */
	@Override
	public void ejecutarHilos(){
		
		//Hilo que lee constantemente el web service que envia el viewmodel
		HiloAuxiliar hiloAuxiliar= new HiloAuxiliar();
		hiloAuxiliar.start();		
	}
	
	
	/**
	 * Este hilo consume constantemente el web service, el cual envia el view model del jee u otra aplicaci�n	 * 
	 * @author Admin	 
	 */
	class HiloAuxiliar extends Thread{
		
		@Override
		public void run() {		
			
			try {	
				
				servicioImpl = new ServicioImplService();
				servicioLocal = servicioImpl.getServicioImpl();
				while(true){			
				  
					capturarViewModelWebService(); 		  
				 
//				 Thread.sleep(1000);			
				}
			
			} catch (IOException e) {
				e.printStackTrace();
			} 
			catch (SAXException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println(e.getMessage());
			}
		}
		
	}	
	
	/**
	 * Metodo que llama el web service y captura los viewmodel que se envian desde otra aplicaci�n
	 * y lo envia a la capa de presentaci�n 
	 * @throws IOException
	 * @throws SAXException 
	 */
	private void capturarViewModelWebService() throws IOException, SAXException {
		
		/*verifica que el archivo auxiliar y original tengan los mismos datos al momento de que se envie un view model
		 *desde otra aplicaci�n*/
		if (verificarCambios()) {

			unirArchivos();
		}
		
		
	}
	
	/**
	 * Metodo que valida si el archivo auxiliar ha recibido nuevos datos.
	 * esto se realiza verificando el tama�o de los dos archivos (original y auxiliar)
	 * @return true si los archivos tienen tama�os diferentes, false si los archivos tienen el mismo tama�o.
	 */
	private boolean verificarCambios() throws SAXException{
		
		UserInterfaceManager interfaceManagerOrg = cargarXMLJAXB(RUTA_JEE_XML_ORG);
		UserInterfaceManager interfaceManagerAux = cargarXMLJAXB(RUTA_JEE_XML_AUX);
		
		List<RetiroVM> retiroVM_XmlOrg = interfaceManagerOrg.getContenedorVistaRetiroViewModel().getContenedorRetiroViewModel().getRetiroVM();
		List<IngresoVM> ingresoVM_XmlOrg = interfaceManagerOrg.getContenedorVistaIngresoViewModel().getContenedorIngresoViewModel().getIngresoVM();
		
		List<RetiroVM> retiroVM_XmlAux = interfaceManagerAux.getContenedorVistaRetiroViewModel().getContenedorRetiroViewModel().getRetiroVM();
		List<IngresoVM> ingresoVM_XmlAux = interfaceManagerAux.getContenedorVistaIngresoViewModel().getContenedorIngresoViewModel().getIngresoVM();
		
		 /*Se verifica que los archivos son diferentes*/
		if((retiroVM_XmlOrg.size() != retiroVM_XmlAux.size()) || (ingresoVM_XmlOrg.size() != ingresoVM_XmlAux.size())){
			
			/*Si el archivo original es mayor que el auxiliar no necesita modificarse, ya que se hacen cambios locales
			 * si es al contrario si necesita modificarse*/
			if(( retiroVM_XmlOrg.size() > retiroVM_XmlAux.size()) || (ingresoVM_XmlOrg.size() > ingresoVM_XmlAux.size())) return false;
			else  return true;
		}else{
			return false;
		}
	}
	
	/**
	 * Metodo que permite univer los datos que llegan del web service al archivo auxiliar
	 * con el archivo original, el cual lee la aplicaci�n para tener los datos en memoria.
	 */
	private void unirArchivos(){		
		
		/**Se realiza la integraci�n de los datos del archivo auxiliar y el archivo original*/
		verificarViewModelOrg_ViewModelAux();		
		
		/**Se notifica a la capa de presentaci�n los cambios*/
		UserInterfaceManager uim=cargarXMLJAXB(RUTA_JEE_XML_ORG);
		setChanged();
		notifyObservers(uim);
		
	}
	
	/**
	 * Metodo que se encarga de unir los datos del view model auxiliar que tiene los datos que llegan del web service y del viewmodel original
	 * el cual es el respaldo de la aplicaci�n. 
	 */
	private void verificarViewModelOrg_ViewModelAux(){		
		
		UserInterfaceManager interfaceManagerOrg = cargarXMLJAXB(RUTA_JEE_XML_ORG);
		UserInterfaceManager interfaceManagerAux = cargarXMLJAXB(RUTA_JEE_XML_AUX);
		
		List<RetiroVM> retiroVM_XmlOrg = interfaceManagerOrg.getContenedorVistaRetiroViewModel().getContenedorRetiroViewModel().getRetiroVM();
		List<IngresoVM> ingresoVM_XmlOrg = interfaceManagerOrg.getContenedorVistaIngresoViewModel().getContenedorIngresoViewModel().getIngresoVM();
		
		List<RetiroVM> retiroVM_XmlAux = interfaceManagerAux.getContenedorVistaRetiroViewModel().getContenedorRetiroViewModel().getRetiroVM();
		List<IngresoVM> ingresoVM_XmlAux = interfaceManagerAux.getContenedorVistaIngresoViewModel().getContenedorIngresoViewModel().getIngresoVM();
		
		/**Se verifica los datos de la lista de ingresos en los dos archivos y se copia los nuevos del archivo auxiliar al original
		 * para que haya integridad en los datos de la aplicaci�n*/
		for (int i = ingresoVM_XmlOrg.size(); i < ingresoVM_XmlAux.size(); i++) {				
					
			/*Se debe crear otro objeto para que la lista del archivo auxiliar conserve todos los objetos,
			* ya que si se le agrega el objeto nuevo de la lista auxiliar a la lista original,
			* este objeto es borrado de la lista auxiliar.*/
			IngresoVM aux= new IngresoVM();
				
			aux.setCuenta(ingresoVM_XmlAux.get(i).getCuenta());
			aux.setDinero(ingresoVM_XmlAux.get(i).getDinero());
			aux.setFecha(ingresoVM_XmlAux.get(i).getFecha());
					
					
			ingresoVM_XmlOrg.add(aux);//se agrega el nuevo objeto del view model auxiliar
		}		
		
		/**Se verifica los datos de la lista de retiros en los dos archivos y se copia los nuevos del archivo auxiliar al original
		 * para que haya integridad en los datos de la aplicaci�n*/
		for (int i = retiroVM_XmlOrg.size(); i < retiroVM_XmlAux.size(); i++) {
			
			/*Se debe crear otro objeto para que la lista del archivo auxiliar conserve todos los objetos,
			* ya que si se le agrega el objeto nuevo de la lista auxiliar a la lista original,
			* este objeto es borrado de la lista auxiliar.*/
			RetiroVM aux= new RetiroVM();
				
			aux.setCuenta(retiroVM_XmlAux.get(i).getCuenta());
			aux.setDinero(retiroVM_XmlAux.get(i).getDinero());
			aux.setFecha(retiroVM_XmlAux.get(i).getFecha());
					
					
			retiroVM_XmlOrg.add(aux);//se agrega el nuevo objeto del view model auxiliar			
				
		}	
		
		/**Se guarda el user interface manager con los nuevos datos almacenados*/
		guardarXMLJAXB(interfaceManagerOrg);
	}

}
