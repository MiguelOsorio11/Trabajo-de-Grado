package org.domain.prueba2tg.servicios;

public class ServicioLocalProxy implements org.domain.prueba2tg.servicios.ServicioLocal {
  private String _endpoint = null;
  private org.domain.prueba2tg.servicios.ServicioLocal servicioLocal = null;
  
  public ServicioLocalProxy() {
    _initServicioLocalProxy();
  }
  
  public ServicioLocalProxy(String endpoint) {
    _endpoint = endpoint;
    _initServicioLocalProxy();
  }
  
  private void _initServicioLocalProxy() {
    try {
      servicioLocal = (new org.domain.prueba2tg.servicios.ServicioImplServiceLocator()).getServicioImplPort();
      if (servicioLocal != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)servicioLocal)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)servicioLocal)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (servicioLocal != null)
      ((javax.xml.rpc.Stub)servicioLocal)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public org.domain.prueba2tg.servicios.ServicioLocal getServicioLocal() {
    if (servicioLocal == null)
      _initServicioLocalProxy();
    return servicioLocal;
  }
  
  public void limpiarObservador() throws java.rmi.RemoteException{
    if (servicioLocal == null)
      _initServicioLocalProxy();
    servicioLocal.limpiarObservador();
  }
  
  public void leerArregloBytes(byte[] arg0) throws java.rmi.RemoteException{
    if (servicioLocal == null)
      _initServicioLocalProxy();
    servicioLocal.leerArregloBytes(arg0);
  }
  
  public boolean generarLectura() throws java.rmi.RemoteException{
    if (servicioLocal == null)
      _initServicioLocalProxy();
    return servicioLocal.generarLectura();
  }
  
  public byte[] crearArregloBytesProduccion() throws java.rmi.RemoteException{
    if (servicioLocal == null)
      _initServicioLocalProxy();
    return servicioLocal.crearArregloBytesProduccion();
  }
  
  
}