/**
 * ServicioLocal.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package org.domain.prueba2tg.servicios;

public interface ServicioLocal extends java.rmi.Remote {
    public void limpiarObservador() throws java.rmi.RemoteException;
    public void leerArregloBytes(byte[] arg0) throws java.rmi.RemoteException;
    public boolean generarLectura() throws java.rmi.RemoteException;
    public byte[] crearArregloBytesProduccion() throws java.rmi.RemoteException;
}
