﻿namespace BancoIngreso
{
    partial class ViewRetiroBanco
    {
        /// <summary> 
        /// Variable del diseñador requerida.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpiar los recursos que se estén utilizando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de componentes

        /// <summary> 
        /// Método necesario para admitir el Diseñador. No se puede modificar 
        /// el contenido del método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupRetiro = new System.Windows.Forms.GroupBox();
            this.buttonRetiro = new System.Windows.Forms.Button();
            this.labelFecha = new System.Windows.Forms.Label();
            this.labelCuenta = new System.Windows.Forms.Label();
            this.labelDinero = new System.Windows.Forms.Label();
            this.textBoxFecha = new System.Windows.Forms.TextBox();
            this.textBoxCuenta = new System.Windows.Forms.TextBox();
            this.textBoxDinero = new System.Windows.Forms.TextBox();
            this.groupRetiro.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupRetiro
            // 
            this.groupRetiro.Controls.Add(this.textBoxDinero);
            this.groupRetiro.Controls.Add(this.textBoxCuenta);
            this.groupRetiro.Controls.Add(this.textBoxFecha);
            this.groupRetiro.Controls.Add(this.labelDinero);
            this.groupRetiro.Controls.Add(this.labelCuenta);
            this.groupRetiro.Controls.Add(this.labelFecha);
            this.groupRetiro.Location = new System.Drawing.Point(15, 14);
            this.groupRetiro.Name = "groupRetiro";
            this.groupRetiro.Size = new System.Drawing.Size(251, 300);
            this.groupRetiro.TabIndex = 0;
            this.groupRetiro.TabStop = false;
            this.groupRetiro.Text = "Retiro";
            // 
            // buttonRetiro
            // 
            this.buttonRetiro.Location = new System.Drawing.Point(88, 320);
            this.buttonRetiro.Name = "buttonRetiro";
            this.buttonRetiro.Size = new System.Drawing.Size(89, 28);
            this.buttonRetiro.TabIndex = 0;
            this.buttonRetiro.Text = "Retirar Dinero";
            this.buttonRetiro.UseVisualStyleBackColor = true;
            // 
            // labelFecha
            // 
            this.labelFecha.AutoSize = true;
            this.labelFecha.Location = new System.Drawing.Point(35, 61);
            this.labelFecha.Name = "labelFecha";
            this.labelFecha.Size = new System.Drawing.Size(43, 13);
            this.labelFecha.TabIndex = 0;
            this.labelFecha.Text = "Fecha :";
            this.labelFecha.Click += new System.EventHandler(this.label2_Click);
            // 
            // labelCuenta
            // 
            this.labelCuenta.AutoSize = true;
            this.labelCuenta.Location = new System.Drawing.Point(35, 107);
            this.labelCuenta.Name = "labelCuenta";
            this.labelCuenta.Size = new System.Drawing.Size(47, 13);
            this.labelCuenta.TabIndex = 1;
            this.labelCuenta.Text = "Cuenta :";
            this.labelCuenta.Click += new System.EventHandler(this.labelCuenta_Click);
            // 
            // labelDinero
            // 
            this.labelDinero.AutoSize = true;
            this.labelDinero.Location = new System.Drawing.Point(35, 150);
            this.labelDinero.Name = "labelDinero";
            this.labelDinero.Size = new System.Drawing.Size(44, 13);
            this.labelDinero.TabIndex = 2;
            this.labelDinero.Text = "Dinero :";
            // 
            // textBoxFecha
            // 
            this.textBoxFecha.Location = new System.Drawing.Point(84, 58);
            this.textBoxFecha.Name = "textBoxFecha";
            this.textBoxFecha.Size = new System.Drawing.Size(129, 20);
            this.textBoxFecha.TabIndex = 3;
            // 
            // textBoxCuenta
            // 
            this.textBoxCuenta.Location = new System.Drawing.Point(84, 104);
            this.textBoxCuenta.Name = "textBoxCuenta";
            this.textBoxCuenta.Size = new System.Drawing.Size(129, 20);
            this.textBoxCuenta.TabIndex = 4;
            // 
            // textBoxDinero
            // 
            this.textBoxDinero.Location = new System.Drawing.Point(84, 147);
            this.textBoxDinero.Name = "textBoxDinero";
            this.textBoxDinero.Size = new System.Drawing.Size(129, 20);
            this.textBoxDinero.TabIndex = 5;
            // 
            // ViewRetiroBanco
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.buttonRetiro);
            this.Controls.Add(this.groupRetiro);
            this.Name = "ViewRetiroBanco";
            this.Size = new System.Drawing.Size(283, 365);
            this.groupRetiro.ResumeLayout(false);
            this.groupRetiro.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupRetiro;
        private System.Windows.Forms.Label labelFecha;
        private System.Windows.Forms.Button buttonRetiro;
        private System.Windows.Forms.Label labelCuenta;
        private System.Windows.Forms.TextBox textBoxFecha;
        private System.Windows.Forms.Label labelDinero;
        private System.Windows.Forms.TextBox textBoxDinero;
        private System.Windows.Forms.TextBox textBoxCuenta;
    }
}
