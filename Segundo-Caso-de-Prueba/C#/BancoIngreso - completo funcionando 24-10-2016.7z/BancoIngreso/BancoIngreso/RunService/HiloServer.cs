﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using BancoIngreso.ModelView;

namespace BancoIngreso.RunService
{
    class HiloServer
    {   


        Thread hiloServicio;
        BancoViewModel bancoViewModel;

        /* Constructor de la clase */
        public HiloServer(ModelView.BancoViewModel bancoViewModel)
        {
            this.bancoViewModel = bancoViewModel;

        }


        public void inicializar()
        {
            hiloServicio = new Thread(new ThreadStart(ejecutarServicios));
            //Iniciamos el hilo 
            hiloServicio.Start();

        }


        public void ejecutarServicios()
        {
           
            while (true)
            {
                bancoViewModel.capturarViewModelWebService();
            }
        }



    }
}
