﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using System.IO;

namespace BancoIngreso.ModelView
{
    class BancoViewModel : PatronObserver.ISujeto
    {
        public static string RUTA_XML_ORG = "D:/WorkSpace Visual Studio/BancoIngreso/BancoIngreso/Resource/c#.xml";
        public static string RUTA_XML_AUX = "D:/WorkSpace Visual Studio/BancoIngreso/BancoIngreso/Resource/c#-aux.xml";


        public void capturarViewModelWebService()
        {
            //se declara la clase que contiene los webservices, la cual es ServicioImplClient y se instancia como cliente el servicio (ServicioImplClient)
            WebServiceReference.ServicioImplClient servicioWeb = new WebServiceReference.ServicioImplClient();

            //Byte[] arreglo = servicioWeb.enviarProduccionJeeWebService();

            Byte[] arreglo = null;
            do
            {
                arreglo = servicioWeb.enviarProduccionJeeWebService();
            } while (arreglo == null);

            //guarda los datos en bytes en el archivo xml
            guardarBytesArchivo(arreglo); 

            if (verificarCambios())
            {
                unirArchivos();
            }

        }

        /**
         * Metodo que se encarga de validar que el identificador del viewmodel y viewpart no esten
         * registrados en la lista del userinterfacemanager
         * @param idNombre
         * @return true si se encuentra el id registrado, false de lo contrario.
         */
        public Boolean validarViewModel_ViewPart(UserInterfaceManager interfaceManager, String idNombre)
        {

            if (!interfaceManager.ViewPart.Any()) //es lo mismo si se dijera isEmpy en java
            {

                for (int i = 0; i < interfaceManager.ViewPart.Count; i++)
                {
                    if (interfaceManager.ViewPart[i].identificador.Equals(idNombre))
                        return true;
                }
            }
            return false;
        }


        /**
         * Metodo que valida si el archivo auxiliar ha recibido nuevos datos.
         * esto se realiza verificando el tamaño de los dos archivos (original y auxiliar)
         * @return true si los archivos tienen tamaños diferentes, false si los archivos tienen el mismo tamaño.
         */
        public Boolean verificarCambios()
        {
            UserInterfaceManager interfaceManagerOrg = cargarResource(RUTA_XML_ORG);
            UserInterfaceManager interfaceManagerAux = cargarResource(RUTA_XML_AUX);


            if (interfaceManagerOrg != null) // si el archivo original no esta vacio, compara los dos archivos
            {

                List<RetiroVM> retiroVM_xmlOrg = interfaceManagerOrg.ContenedorVistaRetiroViewModel.ContenedorRetiroViewModel.RetiroVM;
                List<IngresoVM> ingresoVM_xmlOrg = interfaceManagerOrg.ContenedorVistaIngresoViewModel.ContenedorIngresoViewModel.IngresoVM;

                if (interfaceManagerAux == null) // si hay un error en el archivo auxiliar, se debe volver a llamar el web service y para ello se retorna false
                    return false;

                List<RetiroVM> retiroVM_xmlAux = interfaceManagerAux.ContenedorVistaRetiroViewModel.ContenedorRetiroViewModel.RetiroVM;
                List<IngresoVM> ingresoVM_xmlAux = interfaceManagerAux.ContenedorVistaIngresoViewModel.ContenedorIngresoViewModel.IngresoVM;

                /*Se verifica que los archivos son diferentes*/
                if ((retiroVM_xmlOrg.Count != retiroVM_xmlAux.Count) || (ingresoVM_xmlOrg.Count != ingresoVM_xmlAux.Count))
                {

                    /*Si el archivo original es mayor que el auxiliar no necesita modificarse, ya que se hacen cambios locales
                     * si es al contrario si necesita modificarse*/
                    if ((retiroVM_xmlOrg.Count > retiroVM_xmlAux.Count) || (ingresoVM_xmlOrg.Count > ingresoVM_xmlAux.Count)) return false;
                    else return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return true; //quiere decir que el archivo original no tiene datos, ya que se abre popr primera vez y el archivo auxiliar contiene todos los datos que llegan al web service
            }
        }


        /**
         * Metodo que permite unir los datos que llegan del web service al archivo auxiliar
         * con el archivo original, el cual lee la aplicación para tener los datos en memoria.
         */
        private void unirArchivos()
        {   
            //se realiza la integración de los datos del archivo auxiliar y el archivo original
            verificarViewModelOrg_ViewModelAux();

            //Se cargan los datos del view model para ser enviados a la capa de presentación (doc)
            UserInterfaceManager uim = cargarResource(RUTA_XML_ORG);
            //se le notifica a la capa de presentación
            Notify(uim);

        }

        /**
         * Metodo que se encarga de unir los datos del view model auxiliar 
         * que tiene los datos que llegan del web service y del viewmodel original
         * el cual es el respaldo de la aplicación. 
         */
        public void verificarViewModelOrg_ViewModelAux(){

            UserInterfaceManager interfaceManagerOrg = cargarResource(RUTA_XML_ORG);
            UserInterfaceManager interfaceManagerAux = cargarResource(RUTA_XML_AUX);

            if (interfaceManagerOrg != null) // si el archivo original no esta vacio, compara los dos archivos
            {

                List<RetiroVM> retiroVM_xmlOrg = interfaceManagerOrg.ContenedorVistaRetiroViewModel.ContenedorRetiroViewModel.RetiroVM;
                List<IngresoVM> ingresoVM_xmlOrg = interfaceManagerOrg.ContenedorVistaIngresoViewModel.ContenedorIngresoViewModel.IngresoVM;

                List<RetiroVM> retiroVM_xmlAux = interfaceManagerAux.ContenedorVistaRetiroViewModel.ContenedorRetiroViewModel.RetiroVM;
                List<IngresoVM> ingresoVM_xmlAux = interfaceManagerAux.ContenedorVistaIngresoViewModel.ContenedorIngresoViewModel.IngresoVM;

                /**Se verifica los datos  de la lista de retiros en los dos archivos y se copia los nuevos del archivo auxiliar
                 * al original para que haya integridad en los datos de la aplicacion*/
                for (int i = retiroVM_xmlOrg.Count; i < retiroVM_xmlAux.Count; i++)
                {
                    RetiroVM aux = new RetiroVM();
                    //sino sirve [], se pone ElementAt(posicion)
                    aux.cuenta = retiroVM_xmlAux[i].cuenta;
                    aux.dinero = retiroVM_xmlAux[i].dinero;
                    aux.fecha = retiroVM_xmlAux[i].fecha;

                    retiroVM_xmlOrg.Add(aux);
                }

                for (int i = ingresoVM_xmlOrg.Count; i < ingresoVM_xmlAux.Count; i++)
                {
                    IngresoVM aux = new IngresoVM();

                    aux.cuenta = ingresoVM_xmlAux[i].cuenta;
                    aux.dinero = ingresoVM_xmlAux[i].dinero;
                    aux.fecha = ingresoVM_xmlAux[i].fecha;

                    ingresoVM_xmlOrg.Add(aux);
                }

                //Se guarda el user interface manager en el archivo original
                salvarResource(interfaceManagerOrg, RUTA_XML_ORG);
                //Se guarda el user interface manager en el archivo auxiliar
                salvarResource(interfaceManagerOrg, RUTA_XML_AUX);
            }
            else
            {
                //Se guarda el user interface manager del archivo auxiliar en el archivo original, ya que el archivo original esta vacio
                salvarResource(interfaceManagerAux, RUTA_XML_ORG);
            }
        }



        /** Método que permite guardar un archivo xml de la producción actual
         */       
        public void salvarResource(UserInterfaceManager userInterfaceManager, string URL)
        {      
                            // __________________________________________________________________________________________________________________
                //elimina el archivo antes de salvar. Se debe eliminar el archivo anterior, ya que genera 
                //inconvenientes al sobreescribir el archivo
                /*if (System.IO.File.Exists(@"" + URL))      
                {
                
                    try
                    {
                        System.IO.File.Delete(@"" + URL);
                    }
                    catch (System.IO.IOException e)
                    {
                        Console.WriteLine(e.Message);
                    }
                }*/
                //------------------------------------------------------------------------------------------------------------------

                //Serialize into a file
                XmlSerializer xs = new XmlSerializer(typeof(UserInterfaceManager));
                TextWriter writer = new StreamWriter(URL);
                xs.Serialize(writer, userInterfaceManager);
                writer.Close();
            
        }

        /*métodos para cargar y salvar desde UserInterfaceManager original*/
        public UserInterfaceManager cargarResource(String ruta)
        {
            UserInterfaceManager interfaceManager = null;
             StreamReader objStreamReader = new StreamReader(ruta);

            try
            {
               
                XmlSerializer xmlReader = new XmlSerializer(typeof(UserInterfaceManager));
                interfaceManager = (UserInterfaceManager)xmlReader.Deserialize(objStreamReader);
                objStreamReader.Close();

                return interfaceManager;

            }catch(System.InvalidOperationException i){

                objStreamReader.Close();
            }

            return interfaceManager;

           
        }

        /**
        * Método que permite leer un arreglo de bytes, de un arreglo del archivo que es invocado de un método de java
        * que devuelve el arrglo del archivo generado al crear una prodción
        */
        public void guardarBytesArchivo(byte[] info)
        {
            //string pathNew = @"D:/td/resource/hojavidaModelFactory.xml";
            string pathNew = @"" + RUTA_XML_AUX;

            try
            {
                // Read the source file into a byte array.
                byte[] bytes = info;
                FileStream newfile = new FileStream(pathNew, FileMode.Create, FileAccess.Write);
                newfile.Write(bytes, 0, bytes.Length);
                newfile.Close();
            }
            catch (FileNotFoundException ioEx)
            {
                Console.WriteLine(ioEx.Message);
            }
        }

    }
}
