﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Xml.Linq;
using Microsoft.Office.Tools.Word;
using Microsoft.VisualStudio.Tools.Applications.Runtime;
using Office = Microsoft.Office.Core;
using Word = Microsoft.Office.Interop.Word;
using BancoIngreso.ModelView;


namespace BancoIngreso
{   
    //Esta clase implementa el Observer (haciendouna asimilación a java)
    public partial class ThisDocument : PatronObserver.IObservador
    {

        ModelView.UserInterfaceManager interfaceManager;     
        

        BancoViewModel bancoViewModel;


        /*se declaran los contenedores necesarios para implementar la view*/
        ViewIngresoBanco viewIngresoBanco; //panel de control de usuario del view model ingreso
        ContenedorVistaIngresoViewModel contenedorVistaIngresoViewModel;
        ContenedorIngresoViewModel contenedorIngresoViewModel;
        List<IngresoVM> listaIngresoVM;   

        ViewRetiroBanco viewRetiroBanco;//panel de control de usuario del view model retiro
        ContenedorVistaRetiroViewModel contenedorVistaRetiroViewModel;
        ContenedorRetiroViewModel contenedorRetiroViewModel;
        List<RetiroVM> listaRetiroVM;        

        ViewPart viewPartRetiro;
        ViewModel viewModelRetiro;

        ViewPart viewPartIngreso;
        ViewModel ViewModelIngreso;
        

        /*declaracion de variables para binding*/
        BindingSource contenedorVistaIngresoViewModelBindingSource;
        BindingSource contenedorIngresoViewModelBindingSource;
       
        BindingSource contenedorVistaRetiroViewModelBindingSource;
        BindingSource contenedorRetiroViewModelBindingSource;

        string identificadorNombreViewModelIngreso;
        string identificadorNombreViewModelRetiro;
   
        
        /**Este metodo es cuando arranca la aplicación, el word*/
        private void ThisDocument_Startup(object sender, System.EventArgs e)
        {
           
            //se crea el observador
            bancoViewModel = new ModelView.BancoViewModel();

            /*Se agrega el elemento a observar (la clase ThisDocument) */
            bancoViewModel.Subscribe(this);


            /*Se carga el viewmodel completo*/
            interfaceManager = bancoViewModel.cargarResource(ModelView.BancoViewModel.RUTA_XML_ORG);          

            //se inicializan los contenedores
            inicializarContenedores();

            //1. Se crea el binding source y se asigna el datasource
            iniBindingSource();

            //2. Se inicializa el databinding con el control de contenido
            iniDataBinding();

            //3. Se cargan los controles de usuario
            cargarUserControl();

            //Se ejecuta el hilo el cual va a estar pendiente del web service
            RunService.HiloServer hilo = new RunService.HiloServer(bancoViewModel);
            hilo.inicializar();

            /*Se crea la tabla dinamica de la lista de ingresos en el viewmodel ingreso*/
            crearTablasDinamicas();

            /*Se obtiene los nombres de las clases del view model de ingreso y retiro*/
            identificadorNombreViewModelIngreso = contenedorVistaIngresoViewModel.GetType().Name + "C#";
            identificadorNombreViewModelRetiro = contenedorVistaRetiroViewModel.GetType().Name + "c#";


           // validarViewParts(interfaceManager);
        }

 	    /**
	     * Se valida que las viewpart y los viewmodel no esten almacenados en la producción xml,
	     * si ya estan registrados, se sigue el proceso.
	     * @param nombre
	     */
        private void validarViewParts(UserInterfaceManager interfaceManager)
        {
            if (!bancoViewModel.validarViewModel_ViewPart(interfaceManager, identificadorNombreViewModelIngreso))
            {
                viewPartIngreso = new ViewPart();

                viewPartIngreso.identificador = identificadorNombreViewModelIngreso;
                interfaceManager.ViewPart.Add(viewPartIngreso);

                ViewModelIngreso = new ViewModel();
                ViewModelIngreso.ViewPart = identificadorNombreViewModelIngreso;
                interfaceManager.ViewModel.Add(ViewModelIngreso);
                viewPartIngreso.ViewModel = ViewModelIngreso.idViewModel;

            }
            if(!bancoViewModel.validarViewModel_ViewPart(interfaceManager, identificadorNombreViewModelRetiro))
            {
                viewPartRetiro = new ViewPart();
          
              //  viewPart.identificador = Type.GetType().BaseType.Name;
                    //.simpleName()+"C#";
                viewPartRetiro.identificador = identificadorNombreViewModelRetiro;
                interfaceManager.ViewPart.Add(viewPartRetiro);

                viewModelRetiro = new ViewModel();

                viewModelRetiro.ViewPart= identificadorNombreViewModelRetiro;
                interfaceManager.ViewModel.Add(viewModelRetiro);
                viewPartRetiro.ViewModel = viewModelRetiro.idViewModel;

            }

        }

        /**
         * Metodo que permite crear las tablas dinamicas de las listas de 
         * los view model de ingreso y retiro en el documento word         
         */
        private void crearTablasDinamicas()
        {
            Word.Range tableLocation = this.Tables[1].Cell(8, 1).Range;
            int filas = listaIngresoVM.Count+1;

            this.Application.ActiveDocument.Tables.Add(tableLocation, filas, 3);
            Word.Table tbl = this.Application.ActiveDocument.Tables[1].Cell(8,1).Tables[1];

           
            tbl.Borders[Word.WdBorderType.wdBorderHorizontal].Visible = true;
            tbl.Borders[Word.WdBorderType.wdBorderVertical].Visible = true;
            tbl.Borders[Word.WdBorderType.wdBorderBottom].Visible = true;
            tbl.Borders[Word.WdBorderType.wdBorderLeft].Visible = true;
            tbl.Borders[Word.WdBorderType.wdBorderRight].Visible = true;
            tbl.Borders[Word.WdBorderType.wdBorderTop].Visible = true;


            Word.Table TablaDatosIngresos = this.Tables[1].Cell(8, 1).Tables[1];



            // Insert document properties into cells.            

            int i = 2;

            /*Se le agregan los titulos a la tabla*/
            TablaDatosIngresos.Cell(1, 1).Range.Text = "Fecha";
            TablaDatosIngresos.Cell(1, 2).Range.Text = "Cuenta";
            TablaDatosIngresos.Cell(1, 3).Range.Text = "Dinero";

            foreach (IngresoVM ingreso in listaIngresoVM)
            {
                TablaDatosIngresos.Cell(i, 1).Range.Text = ingreso.fecha;
                TablaDatosIngresos.Cell(i, 2).Range.Text = ingreso.cuenta;
                TablaDatosIngresos.Cell(i, 3).Range.Text = ingreso.dinero;

                i++;
            }


            Word.Range tableLocation1 = this.Tables[2].Cell(8, 1).Range;
            int filas2 = listaRetiroVM.Count + 1;

            this.Application.ActiveDocument.Tables.Add(tableLocation1, filas2, 3);
            Word.Table tbl1 = this.Application.ActiveDocument.Tables[2].Cell(8, 1).Tables[1];


            tbl1.Borders[Word.WdBorderType.wdBorderHorizontal].Visible = true;
            tbl1.Borders[Word.WdBorderType.wdBorderVertical].Visible = true;
            tbl1.Borders[Word.WdBorderType.wdBorderBottom].Visible = true;
            tbl1.Borders[Word.WdBorderType.wdBorderLeft].Visible = true;
            tbl1.Borders[Word.WdBorderType.wdBorderRight].Visible = true;
            tbl1.Borders[Word.WdBorderType.wdBorderTop].Visible = true;


            Word.Table tablaDatosRetiro = this.Tables[2].Cell(8, 1).Tables[1];

            int j = 2;

            /*Se le agregan los titulos a la tabla*/
            tablaDatosRetiro.Cell(1, 1).Range.Text = "Fecha";
            tablaDatosRetiro.Cell(1, 2).Range.Text = "Cuenta";
            tablaDatosRetiro.Cell(1, 3).Range.Text = "Dinero";

            foreach (RetiroVM retiro in listaRetiroVM)
            {
                tablaDatosRetiro.Cell(j, 1).Range.Text = retiro.fecha;
                tablaDatosRetiro.Cell(j, 2).Range.Text = retiro.cuenta;
                tablaDatosRetiro.Cell(j, 3).Range.Text = retiro.dinero;

                j++;
            }

                        
        }

        private void ThisDocument_Shutdown(object sender, System.EventArgs e)
        {
        }

        #region Código generado por el Diseñador de VSTO

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido del método con el editor de código.
        /// </summary>
        private void InternalStartup()
        {
            this.Startup += new System.EventHandler(this.ThisDocument_Startup);
            this.Shutdown += new System.EventHandler(this.ThisDocument_Shutdown);

        }

        #endregion

        private void groupIngreso_Entering(object sender, ContentControlEnteringEventArgs e)
        {

        }

        private void inicializarContenedores()
        {
            viewIngresoBanco = new ViewIngresoBanco();
            viewRetiroBanco = new ViewRetiroBanco();

            if (interfaceManager == null) // si el user inteface es vacio se crea todo de cero
            {
                contenedorVistaIngresoViewModel = new ContenedorVistaIngresoViewModel();
                contenedorIngresoViewModel = new ContenedorIngresoViewModel();
                contenedorVistaIngresoViewModel.ContenedorIngresoViewModel = contenedorIngresoViewModel;

                contenedorVistaRetiroViewModel = new ContenedorVistaRetiroViewModel();
                contenedorRetiroViewModel = new ContenedorRetiroViewModel();
                contenedorVistaRetiroViewModel.ContenedorRetiroViewModel = contenedorRetiroViewModel;

                listaRetiroVM = new List<RetiroVM>();
                listaIngresoVM = new List<IngresoVM>();

            }
            else //si el user interface tiene datos, se obtienen esos datos en los contenedores
            {
                contenedorVistaIngresoViewModel = interfaceManager.ContenedorVistaIngresoViewModel;
                contenedorIngresoViewModel = contenedorVistaIngresoViewModel.ContenedorIngresoViewModel;
                listaIngresoVM = contenedorIngresoViewModel.IngresoVM;

                contenedorVistaRetiroViewModel = interfaceManager.ContenedorVistaRetiroViewModel;
                contenedorRetiroViewModel = contenedorVistaRetiroViewModel.ContenedorRetiroViewModel;
                listaRetiroVM = contenedorRetiroViewModel.RetiroVM;
            }

        }


        private void iniBindingSource()
        {

            //1. Crear una instancia de los BindingSource
            contenedorVistaIngresoViewModelBindingSource = new BindingSource();
            contenedorIngresoViewModelBindingSource = new BindingSource();

            contenedorVistaRetiroViewModelBindingSource = new BindingSource();
            contenedorRetiroViewModelBindingSource = new BindingSource();
          

            //2. Asociar el BindingSource al respectivo DataSource
            //inicializo datasource de componentes
            contenedorVistaIngresoViewModelBindingSource.DataSource = contenedorVistaIngresoViewModel;
            contenedorIngresoViewModelBindingSource.DataSource = contenedorIngresoViewModel;

            contenedorVistaRetiroViewModelBindingSource.DataSource = contenedorVistaRetiroViewModel;
            contenedorRetiroViewModelBindingSource.DataSource = contenedorRetiroViewModel;  
        }

        private void iniDataBinding() 
        {
            //binding view ingreso 
            textboxfechaingreso.DataBindings.Add("Text", this.contenedorIngresoViewModel,"fecha",true,DataSourceUpdateMode.OnPropertyChanged);
            textboxdineroingreso.DataBindings.Add("Text", this.contenedorIngresoViewModel,"dinero",true, DataSourceUpdateMode.OnPropertyChanged);
            textboxcuentaingreso.DataBindings.Add("Text", this.contenedorIngresoViewModel, "cuenta", true, DataSourceUpdateMode.OnPropertyChanged);


            //bindigs view retiro
            textboxfecharetiro.DataBindings.Add("Text", this.contenedorRetiroViewModel, "fecha", true, DataSourceUpdateMode.OnPropertyChanged);
            textboxcuentaretiro.DataBindings.Add("Text", this.contenedorRetiroViewModel, "cuenta", true, DataSourceUpdateMode.OnPropertyChanged);
            texboxdineroretiro.DataBindings.Add("Text", this.contenedorRetiroViewModel, "dinero", true, DataSourceUpdateMode.OnPropertyChanged);         
            
         }

        private void cargarUserControl()
        {

            /**Se agrega el control de usuario ViewIngresoBanco al panel de acciones de documento ActionsPane*/
            ActionsPane.Controls.Add(viewIngresoBanco);

            /**Se agrega el control de usuario ViewIngresoBanco al panel de acciones de documento ActionsPane*/
            ActionsPane.Controls.Add(viewRetiroBanco);

            /**Metodo que invalida el ingreso de datos a los campos. Solo los deja leer*/
            bloquearInputs();
        }

        private void bloquearInputs()
        {

            /*el metodo lockcontents se setea a true para que no se pueda editar los campos*/

            //view model retiro
            textboxfecharetiro.LockContents = true;
            textboxcuentaretiro.LockContents = true;
            texboxdineroretiro.LockContents = true;

            //view model ingreso
            textboxfechaingreso.LockContents = true;
            textboxdineroingreso.LockContents = true;
            textboxcuentaingreso.LockContents = true;
        }

        public void update(ModelView.UserInterfaceManager interfaceManager)
        {
            this.interfaceManager = interfaceManager;

            /**Se actualizan los contenedores y listas*/

            inicializarContenedores();


            //iniBindingSource();

            //se limpian todos los campos
           // clearDataBindigs();

            //SE ACTUALIZA LA VIEW DE INGRESO
           /* contenedorVistaIngresoViewModel = this.interfaceManager.ContenedorVistaIngresoViewModel;
            contenedorIngresoViewModel = contenedorVistaIngresoViewModel.ContenedorIngresoViewModel;
            listaIngresoVM = contenedorIngresoViewModel.IngresoVM;

            //SE ACTUALIZA LA VIEW DE RETIRO
            contenedorVistaRetiroViewModel = this.interfaceManager.ContenedorVistaRetiroViewModel;
            contenedorRetiroViewModel = contenedorVistaRetiroViewModel.ContenedorRetiroViewModel;
            listaRetiroVM = contenedorRetiroViewModel.RetiroVM;*/

                     
            MessageBox.Show("Han llegado nuevos datos","Notificación");

            crearTablasDinamicas();

        }

        public void clearDataBindigs() 
        {   //se limpian los bindigs del view model de ingreso
            textboxcuentaingreso.DataBindings.Clear();
            textboxdineroingreso.DataBindings.Clear();
            textboxfecharetiro.DataBindings.Clear();

            //se limpian los bindigs del view model de retiro
            texboxdineroretiro.DataBindings.Clear();
            textboxfecharetiro.DataBindings.Clear();
            textboxcuentaretiro.DataBindings.Clear();
        }

        private void groupIngreso_Entering_1(object sender, ContentControlEnteringEventArgs e)
        {

        }
       

    }
}
