﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace BancoIngreso.PatronObserver
{
    abstract class ISujeto
    {
        ArrayList coleccionObservadores = new ArrayList();

        /// <summary>
        /// Método encargado de notificar a todos y cada uno de los observadores que ha 
        /// sucedido "algo".
        /// Esto se realiza recorriendo todos los observadores subscritos y ejecutando por 
        /// cada uno de ellos el método UpdateState() implementado de IObserver.
        /// </summary>
        public void Notify(ModelView.UserInterfaceManager uim)
        {
            foreach(ThisDocument observadores in coleccionObservadores)
            {
                observadores.update(uim);
            }
        }

        /// <summary>
        /// Método encargado de subscribir un observador para que reciba las notificaciones.
        /// </summary>
        /// <param name="observer">Interfaz IObserver que indica el observador.</param>
        public void Subscribe(ThisDocument observer)
        {
            coleccionObservadores.Add(observer);
        }

        /// <summary>
        /// Método encargado de desubscribir un observador para que no reciba más 
        /// notificaciones.
        /// </summary>
        /// <param name="observer">Interfaz IObserver que indica el observador.</param>
        public void Unsubscribe(ThisDocument observer)
        {
            coleccionObservadores.Remove(observer);
        }
    }
}
