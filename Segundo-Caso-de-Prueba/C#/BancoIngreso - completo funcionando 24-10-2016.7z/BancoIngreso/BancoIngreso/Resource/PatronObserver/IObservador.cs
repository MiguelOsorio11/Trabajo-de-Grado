﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BancoIngreso.ModelView;

namespace BancoIngreso.PatronObserver
{
    interface IObservador
    {

        //documet es la interfaz a la que se le va a notificar
        void update(UserInterfaceManager userInterfazManager);
    }
}
