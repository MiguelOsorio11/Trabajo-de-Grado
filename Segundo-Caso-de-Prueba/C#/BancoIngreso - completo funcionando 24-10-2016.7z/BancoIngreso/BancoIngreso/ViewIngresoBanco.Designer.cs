﻿namespace BancoIngreso
{
    partial class ViewIngresoBanco
    {
        /// <summary> 
        /// Variable del diseñador requerida.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpiar los recursos que se estén utilizando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de componentes

        /// <summary> 
        /// Método necesario para admitir el Diseñador. No se puede modificar 
        /// el contenido del método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBoxIngreso = new System.Windows.Forms.GroupBox();
            this.textBoxDinero = new System.Windows.Forms.TextBox();
            this.textBoxCuenta = new System.Windows.Forms.TextBox();
            this.textBoxFecha = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.labelFecha = new System.Windows.Forms.Label();
            this.buttonIngresar = new System.Windows.Forms.Button();
            this.groupBoxIngreso.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBoxIngreso
            // 
            this.groupBoxIngreso.Controls.Add(this.textBoxDinero);
            this.groupBoxIngreso.Controls.Add(this.textBoxCuenta);
            this.groupBoxIngreso.Controls.Add(this.textBoxFecha);
            this.groupBoxIngreso.Controls.Add(this.label2);
            this.groupBoxIngreso.Controls.Add(this.label1);
            this.groupBoxIngreso.Controls.Add(this.labelFecha);
            this.groupBoxIngreso.Location = new System.Drawing.Point(16, 20);
            this.groupBoxIngreso.Name = "groupBoxIngreso";
            this.groupBoxIngreso.Size = new System.Drawing.Size(263, 372);
            this.groupBoxIngreso.TabIndex = 0;
            this.groupBoxIngreso.TabStop = false;
            this.groupBoxIngreso.Text = "Retiro";
            this.groupBoxIngreso.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // textBoxDinero
            // 
            this.textBoxDinero.Location = new System.Drawing.Point(99, 168);
            this.textBoxDinero.Name = "textBoxDinero";
            this.textBoxDinero.Size = new System.Drawing.Size(112, 20);
            this.textBoxDinero.TabIndex = 5;
            // 
            // textBoxCuenta
            // 
            this.textBoxCuenta.Location = new System.Drawing.Point(100, 114);
            this.textBoxCuenta.Name = "textBoxCuenta";
            this.textBoxCuenta.Size = new System.Drawing.Size(111, 20);
            this.textBoxCuenta.TabIndex = 4;
            // 
            // textBoxFecha
            // 
            this.textBoxFecha.Location = new System.Drawing.Point(100, 64);
            this.textBoxFecha.Name = "textBoxFecha";
            this.textBoxFecha.Size = new System.Drawing.Size(111, 20);
            this.textBoxFecha.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(49, 171);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Dinero :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(49, 117);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(47, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Cuenta :";
            // 
            // labelFecha
            // 
            this.labelFecha.AutoSize = true;
            this.labelFecha.Location = new System.Drawing.Point(49, 67);
            this.labelFecha.Name = "labelFecha";
            this.labelFecha.Size = new System.Drawing.Size(43, 13);
            this.labelFecha.TabIndex = 0;
            this.labelFecha.Text = "Fecha :";
            // 
            // buttonIngresar
            // 
            this.buttonIngresar.Location = new System.Drawing.Point(94, 398);
            this.buttonIngresar.Name = "buttonIngresar";
            this.buttonIngresar.Size = new System.Drawing.Size(89, 24);
            this.buttonIngresar.TabIndex = 7;
            this.buttonIngresar.Text = "Ingresar";
            this.buttonIngresar.UseVisualStyleBackColor = true;
            // 
            // ViewIngresoBanco
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.buttonIngresar);
            this.Controls.Add(this.groupBoxIngreso);
            this.Name = "ViewIngresoBanco";
            this.Size = new System.Drawing.Size(297, 435);
            this.groupBoxIngreso.ResumeLayout(false);
            this.groupBoxIngreso.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBoxIngreso;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label labelFecha;
        private System.Windows.Forms.TextBox textBoxDinero;
        private System.Windows.Forms.TextBox textBoxCuenta;
        private System.Windows.Forms.TextBox textBoxFecha;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button buttonIngresar;
    }
}
